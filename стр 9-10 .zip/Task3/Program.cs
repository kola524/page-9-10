﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 12;
            int b = 13;
            Console.Write("a=" + a); Console.Write(" b=" + b);
        }
    }
}
