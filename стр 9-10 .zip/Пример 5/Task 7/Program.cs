﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите вещественное число:");
            string b = Console.ReadLine();
            double A = double.Parse(b);
        }
    }
}
