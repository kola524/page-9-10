﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число F");
            int F = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(F);
        }
    }
}
