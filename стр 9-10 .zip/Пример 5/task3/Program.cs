﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string b = Console.ReadLine();
            int F = int.Parse(b);
            Console.WriteLine(F);
        }
    }
}
