﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double A = 12.6;
            Console.Write("A={0,10:N2}", A);
        }
    }
}
