﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double D = 14.312;
            int L = 190;

            Console.Write("{0:G}", D);
            Console.Write("{0:G}", L);
        }
    }
}
