﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 12;
            int b = 13;
            Console.WriteLine("Вначале выводится число A={0}, затем B={1}, и потом их сумма ={2}", a, b, a + b);



        }
    }
}
